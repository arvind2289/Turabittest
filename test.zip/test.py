lowerCaseList = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
                 "u", "v", "w", "x", "y", "z"]

upperCaseList = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                 "U", "V", "W", "X", "Y", "Z"]


def assignment1():
    inputString = '''Hello world
					 Practice makes perfect'''
    newString = ""
    for element in inputString:
        try:
            newString = newString + upperCaseList[lowerCaseList.index(element)]
        except:
            newString = newString + element
    print(newString)
    print("Assignment 1 ends")
    print("#####################################################")


assignment1()


def assignment2():
    inputString = "hello world and practice makes perfect and hello world again"
    tempStr = ""
    processList = list()
    flag = 0
    for element in inputString:
        if element == " ":
            processList.append(tempStr)
            tempStr = ""
            flag = 0
        else:
            tempStr = tempStr + element
    processList2 = list()
    # Romoving duplicate
    for i in range(len(processList)):
        flag = 0
        j = i + 1
        for x in range(j, len(processList)):
            if processList[i] == processList[x]:
                flag = 1
        if flag == 0:
            processList2.append(processList[i])
    #  Shorting
    swap = ""
    for i in range(len(processList2)):
        j = i + 1
        for x in range(j, len(processList2)):
            if lowerCaseList.index(processList2[i][0]) > lowerCaseList.index(processList2[x][0]):
                swap = processList2[x]
                processList2[x] = processList2[i]
                processList2[i] = swap
            else:
                swap = processList2[i]
    outputString = ""
    for word in processList2:
        if outputString == "":
            outputString = word
        else:
            outputString = outputString + " " + word
    print(outputString)
    print("Assignment 2 ends")
    print("#####################################################")


assignment2()


def assignment3():
    for rabbits in range(1, 34):
        chickens = 35 - rabbits
        rabbitsLegs = 4 * rabbits
        chickensLegs = 2 * chickens
        if (rabbitsLegs + chickensLegs) == 94:
            break
    print(str(rabbits) + " rabits and " + str(chickens) + " chickens")
    print("Assignment 3 ends")
    print("#####################################################")


assignment3()


#assignment 4

import json
def containinglatter(mylist):
    try:

        my_dict = {i: mylist.count(i) for i in mylist} ## using Lanbda function
        r = json.dumps(my_dict,indent=4)
        loaded_r = json.loads(r)
        return r
    except:
        print("please enter valid list")
    #print(my_dict,'helloooo')



mylist = ['python', 'pyhton3', 'user1', 'assignment', 'user', 'user1',
          'python', 'User1']
list= input("please enter list")
print(containinglatter(mylist))
print("Assignment 4 ends")
print("#####################################################")




def Assignment5(List):
    try:
        final_list = []
        for num in List:
            if num not in final_list:
                final_list.append(num)
        return final_list
    except:
        print("enter vaild list")

list= input("please enter list")
List =   [1,2,55,1,3,2,34,55]
print(Assignment5(List))
print("Assignment 5 ends")
print("#####################################################")




